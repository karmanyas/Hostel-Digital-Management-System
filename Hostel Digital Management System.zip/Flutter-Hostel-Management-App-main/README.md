# About HAppY

HAppY is an Android Application made for Hostlers of MUJ so that they can avail benefits of applying Online request for Out Pass and Guest Room Booking Approvals.

Students can also get information about Mess Menu from the app itself.

In Similar Fashion Hostel Authority can also manage student requests on this app and take decision accordingly which help them reduce paper work and enable to maintain proper records as well. 


## Installation


[Click Here](https://) to install apk file on your Android Device.


_For New Users_ :

-  Sign Up on HAppY as Student or Hostel Employee as per your choice
- After you register, An email verification link will be sent on registered Email ID.
- Click on the link received on registered Email ID to verify your account so that you can use application
- Now You are registered and You can login on HAppY


_For Registered User:_

-  Login with your registered Email ID and Password

## System Requirement 

Android Device with Android Version 6.0 and above
