class HostelInChargeField {
  String userNameHostel;
  String empIdHostel;
  String designationHostel;
  String personalEmailIdHostel;
  String collegeEmailIdHostel;
  int contactNumberHostel;

  HostelInChargeField(
      this.userNameHostel,
      this.empIdHostel,
      this.designationHostel,
      this.personalEmailIdHostel,
      this.collegeEmailIdHostel,
      this.contactNumberHostel);
}
