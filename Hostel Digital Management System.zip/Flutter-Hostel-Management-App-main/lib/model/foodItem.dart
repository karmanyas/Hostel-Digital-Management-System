class FoodItem{
  final String name;
  FoodItem({this.name});
}